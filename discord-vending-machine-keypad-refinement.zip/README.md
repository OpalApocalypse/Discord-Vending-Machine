# Discord Vending Machine

A Discord bot that turns server memes, quotes, links, images, and inside jokes into a little vending machine ritual.

Post the machine, pick a slot like `A1`, and the bot makes a small show of dispensing the result into a configured dropbox channel.

The machine post is a standalone bot message with a simple display and keypad. Users press A/B/C, then 1/2/3, then press Dispense.

## What it does

- Posts a standalone bot-authored vending machine message, so `/machine` does not appear as the public machine post.
- Shows vending-machine artwork first, then a lower display panel with status and current keypad input.
- Bundles `src/main/resources/vending-machine.png` as artwork inside the machine embed above the keypad buttons.
- Displays image links from either `imageUrl` or `content`, and normalizes simple Imgur page links such as `https://imgur.com/abc123` into direct Discord-embeddable image links.
- Treats dispensed items as collectibles owned by the Discord user who dispensed them.
- Removes claimed stock from the machine, so the same item is not dispensed twice.
- Supports a simple coin balance, a default cost of `1` coin per dispense, and admin coin grants.
- Supports `/vend code` for modern Discord slash-command use.
- Shows the coin/gears/clunk sequence in the public machine display's `STATUS` line.
- Dispenses the final item into a configured output channel.
- Temporarily turns the display status into a `Grab your item here` link after a vend, then resets it.
- Stores editable stock/settings in `data/machine.json`.
- Includes admin stock commands for adding, clearing, enabling, disabling, and reloading slots.

## Requirements

- Java 21
- Maven 3.9+, or the included `mvnw.cmd` wrapper on Windows
- A Discord bot token

## Setup

1. Copy `.env.example` to `.env`.
2. Set `DISCORD_TOKEN`.
3. For faster slash-command testing, set `GUILD_ID` to your test server ID. Leave it blank for global commands.
4. Invite the bot with the `bot` and `applications.commands` scopes.
5. Run on Windows PowerShell:

```powershell
.\mvnw.cmd package
java -jar .\target\discord-vending-machine-1.0.0-SNAPSHOT.jar
```

If you already installed Maven, `mvn package` works too. On first launch, the bot creates `data/machine.json` with sample stock.

## Commands

- `/machine` posts the current vending machine.
- `/vend code:A1` dispenses from a slot.
- `/stock list` shows slots, item counts, and dispense counts.
- `/stock add code:A1 label:Cats content:...` adds an item to a slot.
- `/stock add-image code:A1 label:Cats image-url:... title:...` adds an image collectible without needing to paste the image URL into `content`.
- `/stock clear code:A1` empties a slot.
- `/stock enable code:A1` and `/stock disable code:A1` toggle availability.
- `/stock set-output channel-id:...` sets the dropbox channel.
- `/stock reload` reloads `data/machine.json` after manual edits.
- `/coins balance` shows your coin balance.
- `/coins balance user:@name` shows another user's balance.
- `/coins grant user:@name amount:1` grants coins.
- `/coins set-manager-role role-id:...` lets a configured role grant coins.
- `/coins set-cost amount:1` sets the vending cost.

Stock commands require Manage Server, Administrator, or `OWNER_ID` in `.env`.
Coin grants require Manage Server, Administrator, `OWNER_ID`, or the configured coin manager role.

For the most vending-machine-like flow, create two channels:

- a vending-machine channel where you post `/machine` and users use the keypad buttons
- a drop-box channel configured with `/stock set-output`, where the actual result appears after a short delay

The public machine shows the machine artwork first, then a lower display panel with `STATUS` and `INPUT`. Discord renders the real clickable controls under the message, so the bot keeps the visible machine compact: row keys A-C, number keys 1-3, then Dispense/Clear. When a user presses Dispense, the keypad briefly disables and the public `STATUS` line cycles through the coin/gears/clunk sequence. The final reveal still lands in the drop-box channel and tags the collector as `Claimed by @user`. If the selected slot is empty, the drop-box posts `@User Oh no! You chose an option that's out of stock! Anyway-`. The machine message then clears the selection, temporarily changes `STATUS` into a `Grab your item here` link, and resets that status after 15 seconds.

To swap the machine artwork, replace `src/main/resources/vending-machine.png` with another PNG using the same filename, then run `.\mvnw.cmd package` again.

## Economy and ownership

Each dispense costs `dispenseCost` coins, which defaults to `1`. Dispensed items are recorded in `ownedItems` under the user's Discord ID, then removed from slot stock so they cannot repeat. On load, stock that matches already-owned items is also removed from active rotation. IDs come from a single machine-wide `nextItemSerial`, so `ID 0001`, `ID 0002`, and onward are unique across every category.

Admins can grant coins immediately with `/coins grant`. The planned earning rules are:

- 1 coin after about 50-100 counted server messages
- 1 coin after about 1 day of passive server presence

Those earning rules need a separate message/activity scheduler pass. They are intentionally not hidden in the current bot yet.

## Stock format

The runtime stock file is JSON:

```json
{
  "title": "VENDING MACHINE",
  "outputChannelId": "",
  "dispenseCost": 1,
  "nextItemSerial": 1,
  "coinManagerRoleId": "",
  "dispenseSequence": [
    "`coin inserted for {code}...`",
    "`gears turning...`",
    "`clunk.`"
  ],
  "slots": {
    "A1": {
      "code": "A1",
      "label": "Cats",
      "enabled": true,
      "dispensed": 0,
      "items": [
        {
          "content": "A tiny cat fact escaped the vending coil.",
          "imageUrl": "",
          "title": "",
          "rare": false,
          "weight": 1
        }
      ]
    }
  },
  "wallets": {},
  "ownedItems": {}
}
```

Set `imageUrl` for image embeds, or put a direct image link in `content`. Direct image URLs work best, such as `https://i.imgur.com/abc123.png`. A simple Imgur page URL like `https://imgur.com/abc123` is converted automatically. Imgur album/gallery links cannot be reliably converted because the URL does not identify one image file. Set `title` to control the collectible output title. Increase `weight` to make an item appear more often. Mark `rare` to give the drop a special color/footer.

## Notes

The original prototype broke because it depended on an old Java Discord API setup and only committed compiled output. This version checks in source code, uses current JDA, includes a Windows Maven wrapper, avoids Message Content Intent, and has CI so dependency breaks are visible sooner.
