package org.oaple.vendingmachine;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.github.cdimascio.dotenv.Dotenv;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.components.actionrow.ActionRow;
import net.dv8tion.jda.api.components.buttons.Button;
import net.dv8tion.jda.api.components.buttons.ButtonStyle;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.InteractionHook;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.interactions.commands.build.SubcommandData;
import net.dv8tion.jda.api.utils.FileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public final class VendingMachineBot extends ListenerAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(VendingMachineBot.class);
    private static final String KEY_PREFIX = "vend:key:";
    private static final String DISPENSE_ID = "vend:dispense";
    private static final String CLEAR_ID = "vend:clear";
    private static final Pattern SLOT_CODE = Pattern.compile("[A-Z][0-9]{1,2}");
    private static final Pattern INPUT_PATTERN = Pattern.compile("`INPUT\\s+([A-C_][1-3_])`");
    private static final Pattern SELECTION_PATTERN = Pattern.compile("\\*\\*Selection:\\*\\* `([A-C_-][1-3_-])`");
    private static final Pattern STATUS_LINK_PATTERN = Pattern.compile("`STATUS\\s*` \\[([^]]+)]\\(([^)]+)\\)");
    private static final Pattern LEGACY_LATEST_LINK_PATTERN = Pattern.compile("`LAST\\s+` \\[([^]]+)]\\(([^)]+)\\)");
    private static final Pattern LEGACY_LATEST_TEXT_PATTERN = Pattern.compile("`LAST\\s+([^`]+)`");
    private static final Pattern DROPBOX_LINK_PATTERN = Pattern.compile("\\*\\*Drop-box:\\*\\* \\[([^]]+)]\\(([^)]+)\\)");
    private static final Pattern DROPBOX_TEXT_PATTERN = Pattern.compile("\\*\\*Drop-box:\\*\\* ([^\\n]+)");
    private static final Color MACHINE_YELLOW = new Color(0xF2B84B);
    private static final Color DROPBOX_GREEN = new Color(0x5BBE7A);
    private static final long DISPENSE_STEP_DELAY_MS = 650;
    private static final String MACHINE_ART_FILE = "vending-machine.png";
    private static final String MACHINE_ART_RESOURCE = "/" + MACHINE_ART_FILE;
    private static final String MACHINE_ART_URL = "attachment://" + MACHINE_ART_FILE;
    private static final long LATEST_DROP_STATUS_SECONDS = 15;

    private final MachineStore store;
    private final Random random = new SecureRandom();
    private final String ownerId;
    private Machine machine;

    private VendingMachineBot(MachineStore store, String ownerId) throws IOException {
        this.store = store;
        this.ownerId = ownerId == null ? "" : ownerId;
        this.machine = normalizeMachine(store.loadOrCreateDefault());
    }

    public static void main(String[] args) throws Exception {
        BotConfig config = BotConfig.load();
        VendingMachineBot bot = new VendingMachineBot(new MachineStore(config.dataPath()), config.ownerId());

        JDA jda = JDABuilder.createDefault(config.token())
                .setStatus(OnlineStatus.ONLINE)
                .setActivity(Activity.playing("with mystery stock"))
                .addEventListeners(bot)
                .build();

        jda.awaitReady();
        registerCommands(jda, config.guildId());
        LOGGER.info("Discord Vending Machine is online.");
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        switch (event.getName()) {
            case "machine" -> handleMachine(event);
            case "vend" -> handleVend(event);
            case "stock" -> handleStock(event);
            case "coins" -> handleCoins(event);
            default -> {
            }
        }
    }

    @Override
    public void onButtonInteraction(ButtonInteractionEvent event) {
        String id = event.getComponentId();
        if (id.startsWith(KEY_PREFIX)) {
            handleKeypad(event, id.substring(KEY_PREFIX.length()));
            return;
        }
        if (id.equals(CLEAR_ID)) {
            handleClearSelection(event);
            return;
        }
        if (!id.equals(DISPENSE_ID)) {
            return;
        }

        MachineView view = machineView(event.getMessage());
        String code = view.selection();
        if (!completeSelection(code)) {
            event.deferEdit().queue();
            return;
        }

        try {
            if (isOutOfStock(code)) {
                dispatchOutOfStock(event, view, code);
                return;
            }
            DispensedItem dispensed = dispense(code, event.getUser());
            dispatchMachineDispense(event, view, dispensed);
        } catch (IllegalArgumentException ex) {
            if (isOutOfStockError(ex)) {
                dispatchOutOfStock(event, view, code);
                return;
            }
            showTemporaryMachineStatus(event, view, publicErrorStatus(ex));
        } catch (IOException ex) {
            showTemporaryMachineStatus(event, view, "machine jammed");
        }
    }

    private void handleMachine(SlashCommandInteractionEvent event) {
        event.deferReply(true).queue(hook -> {
            var action = event.getMessageChannel()
                    .sendMessageEmbeds(machineEmbeds(machine(), MachineView.empty()))
                    .setComponents(keypadButtons("__"));
            FileUpload upload = machineArtUpload();
            if (upload != null) {
                action = action.addFiles(upload);
            }
            action.queue(
                    sent -> replyPrivately(hook, "Machine posted."),
                    failure -> replyPrivately(hook, "Could not post the machine. Check the bot logs.")
            );
        });
    }

    private void handleVend(SlashCommandInteractionEvent event) {
        String code = Objects.requireNonNull(event.getOption("code")).getAsString();
        event.deferReply(true).queue(hook -> {
            try {
                if (isOutOfStock(code)) {
                    resolveOutputChannel(event.getGuild(), event.getMessageChannel())
                            .sendMessage(outOfStockMessage(event.getUser()))
                            .queue(
                                    delivered -> hook.deleteOriginal().queue(null, failure -> LOGGER.warn("Could not clear private vend acknowledgement.", failure)),
                                    failure -> replyPrivately(hook, "The drop-box jammed while delivering the item. Check the bot logs.")
                            );
                    return;
                }
                DispensedItem dispensed = dispense(code, event.getUser());
                resolveOutputChannel(event.getGuild(), event.getMessageChannel())
                        .sendMessage(dropBoxMessageContent(dispensed))
                        .setEmbeds(dispenseEmbed(dispensed))
                        .queue(
                                delivered -> hook.deleteOriginal().queue(null, failure -> LOGGER.warn("Could not clear private vend acknowledgement.", failure)),
                                failure -> replyPrivately(hook, "The drop-box jammed while delivering the item. Check the bot logs.")
                        );
            } catch (IllegalArgumentException ex) {
                if (isOutOfStockError(ex)) {
                    resolveOutputChannel(event.getGuild(), event.getMessageChannel())
                            .sendMessage(outOfStockMessage(event.getUser()))
                            .queue(
                                    delivered -> hook.deleteOriginal().queue(null, failure -> LOGGER.warn("Could not clear private vend acknowledgement.", failure)),
                                    failure -> replyPrivately(hook, "The drop-box jammed while delivering the item. Check the bot logs.")
                            );
                    return;
                }
                replyPrivately(hook, ex.getMessage());
            } catch (IOException ex) {
                replyPrivately(hook, "The machine jammed while saving stock data. Check the bot logs.");
            }
                });
    }

    private void handleKeypad(ButtonInteractionEvent event, String key) {
        MachineView view = machineView(event.getMessage());
        String selection = applyKey(view.selection(), key);
        event.editMessageEmbeds(machineEmbeds(machine(), view.withSelection(selection)))
                .setComponents(keypadButtons(selection))
                .queue();
    }

    private void handleClearSelection(ButtonInteractionEvent event) {
        MachineView view = machineView(event.getMessage()).withSelection("__");
        event.editMessageEmbeds(machineEmbeds(machine(), view))
                .setComponents(keypadButtons(view.selection()))
                .queue();
    }

    private void handleStock(SlashCommandInteractionEvent event) {
        if (!isManager(event.getMember())) {
            event.reply("Only server managers can restock the machine.").setEphemeral(true).queue();
            return;
        }

        try {
            switch (event.getSubcommandName() == null ? "" : event.getSubcommandName()) {
                case "list" -> event.reply(stockSummary()).setEphemeral(true).queue();
                case "reload" -> {
                    reload();
                    event.reply("Reloaded stock from disk.").setEphemeral(true).queue();
                }
                case "add" -> handleStockAdd(event);
                case "add-image" -> handleStockAddImage(event);
                case "clear" -> handleStockClear(event);
                case "enable" -> handleStockEnabled(event, true);
                case "disable" -> handleStockEnabled(event, false);
                case "set-output" -> handleSetOutput(event);
                default -> event.reply("Unknown stock command.").setEphemeral(true).queue();
            }
        } catch (IOException ex) {
            event.reply("Could not save stock data. Check the bot logs.").setEphemeral(true).queue();
        } catch (IllegalArgumentException ex) {
            event.reply(ex.getMessage()).setEphemeral(true).queue();
        }
    }

    private void handleStockAdd(SlashCommandInteractionEvent event) throws IOException {
        String code = Objects.requireNonNull(event.getOption("code")).getAsString();
        String label = Objects.requireNonNull(event.getOption("label")).getAsString();
        String content = Objects.requireNonNull(event.getOption("content")).getAsString();
        String imageUrl = event.getOption("image-url") == null ? "" : Objects.requireNonNull(event.getOption("image-url")).getAsString();
        String title = event.getOption("title") == null ? "" : Objects.requireNonNull(event.getOption("title")).getAsString();
        boolean rare = event.getOption("rare") != null && Objects.requireNonNull(event.getOption("rare")).getAsBoolean();
        Slot slot = addStock(code, label, new StockItem(content, imageUrl, title, rare, 1));
        event.reply("Restocked `" + slot.getCode() + "` with `" + slot.getLabel() + "`.").setEphemeral(true).queue();
    }

    private void handleStockAddImage(SlashCommandInteractionEvent event) throws IOException {
        String code = Objects.requireNonNull(event.getOption("code")).getAsString();
        String label = Objects.requireNonNull(event.getOption("label")).getAsString();
        String imageUrl = Objects.requireNonNull(event.getOption("image-url")).getAsString();
        String title = event.getOption("title") == null ? "" : Objects.requireNonNull(event.getOption("title")).getAsString();
        boolean rare = event.getOption("rare") != null && Objects.requireNonNull(event.getOption("rare")).getAsBoolean();
        Slot slot = addStock(code, label, new StockItem("", imageUrl, title, rare, 1));
        event.reply("Added image stock to `" + slot.getCode() + "` under `" + slot.getLabel() + "`.").setEphemeral(true).queue();
    }

    private void handleStockClear(SlashCommandInteractionEvent event) throws IOException {
        String code = Objects.requireNonNull(event.getOption("code")).getAsString();
        clearSlot(code);
        event.reply("Cleared `" + normalizeCode(code) + "`.").setEphemeral(true).queue();
    }

    private void handleStockEnabled(SlashCommandInteractionEvent event, boolean enabled) throws IOException {
        String code = Objects.requireNonNull(event.getOption("code")).getAsString();
        setEnabled(code, enabled);
        event.reply((enabled ? "Enabled " : "Disabled ") + "`" + normalizeCode(code) + "`.").setEphemeral(true).queue();
    }

    private void handleSetOutput(SlashCommandInteractionEvent event) throws IOException {
        String channelId = Objects.requireNonNull(event.getOption("channel-id")).getAsString();
        setOutputChannelId(channelId);
        event.reply("Dispense output channel set to `<#" + cleanSnowflake(channelId) + ">`.").setEphemeral(true).queue();
    }

    private void handleCoins(SlashCommandInteractionEvent event) {
        try {
            switch (event.getSubcommandName() == null ? "" : event.getSubcommandName()) {
                case "balance" -> {
                    User user = event.getOption("user") == null ? event.getUser() : Objects.requireNonNull(event.getOption("user")).getAsUser();
                    event.reply(user.getName() + " has `" + coinBalance(user.getId()) + "` coin(s).").setEphemeral(true).queue();
                }
                case "grant" -> {
                    if (!isCoinManager(event.getMember())) {
                        event.reply("Only coin managers can grant coins.").setEphemeral(true).queue();
                        return;
                    }
                    User user = Objects.requireNonNull(event.getOption("user")).getAsUser();
                    long amount = Objects.requireNonNull(event.getOption("amount")).getAsLong();
                    grantCoins(user.getId(), amount);
                    event.reply("Granted `" + amount + "` coin(s) to " + user.getAsMention() + ".").setEphemeral(true).queue();
                }
                case "set-manager-role" -> {
                    if (!isManager(event.getMember())) {
                        event.reply("Only server managers can set the coin manager role.").setEphemeral(true).queue();
                        return;
                    }
                    String roleId = Objects.requireNonNull(event.getOption("role-id")).getAsString();
                    setCoinManagerRoleId(roleId);
                    event.reply("Coin manager role set to `<@&" + cleanSnowflake(roleId) + ">`.").setEphemeral(true).queue();
                }
                case "set-cost" -> {
                    if (!isManager(event.getMember())) {
                        event.reply("Only server managers can set the machine cost.").setEphemeral(true).queue();
                        return;
                    }
                    long cost = Objects.requireNonNull(event.getOption("amount")).getAsLong();
                    setDispenseCost(cost);
                    event.reply("Machine cost set to `" + Math.max(0, cost) + "` coin(s).").setEphemeral(true).queue();
                }
                default -> event.reply("Unknown coins command.").setEphemeral(true).queue();
            }
        } catch (IOException ex) {
            event.reply("Could not save coin data. Check the bot logs.").setEphemeral(true).queue();
        } catch (IllegalArgumentException ex) {
            event.reply(ex.getMessage()).setEphemeral(true).queue();
        }
    }


    private synchronized Machine machine() {
        return machine;
    }

    private synchronized void reload() throws IOException {
        machine = normalizeMachine(store.loadOrCreateDefault());
    }

    private synchronized DispensedItem dispense(String rawCode, User user) throws IOException {
        String code = normalizeCode(rawCode);
        Slot slot = machine.getSlots().get(code);
        if (slot == null) {
            throw new IllegalArgumentException("`" + code + "` is not stocked in this machine.");
        }
        if (!slot.isEnabled()) {
            throw new IllegalArgumentException("`" + code + "` is currently sold out.");
        }
        if (slot.getItems().isEmpty()) {
            throw new IllegalArgumentException("`" + code + "` rattles sadly. Nothing is inside.");
        }

        long cost = Math.max(0, machine.getDispenseCost());
        if (cost > 0) {
            Wallet wallet = walletFor(user.getId());
            if (wallet.getBalance() < cost) {
                throw new IllegalArgumentException("You need `" + cost + "` coin(s) to use the machine. You have `" + wallet.getBalance() + "`.");
            }
            wallet.setBalance(wallet.getBalance() - cost);
        }

        StockItem item = choose(slot);
        slot.getItems().remove(item);
        slot.setDispensed(slot.getDispensed() + 1);
        long serial = machine.getNextItemSerial();
        machine.setNextItemSerial(serial + 1);
        recordOwnership(user, slot, item, serial);
        store.save(machine);
        return new DispensedItem(slot, item, serial, user.getId(), user.getName());
    }

    private synchronized boolean isOutOfStock(String rawCode) {
        String code = normalizeCode(rawCode);
        Slot slot = machine.getSlots().get(code);
        if (slot == null) {
            throw new IllegalArgumentException("`" + code + "` is not stocked in this machine.");
        }
        if (!slot.isEnabled()) {
            throw new IllegalArgumentException("`" + code + "` is currently sold out.");
        }
        return slot.getItems().isEmpty();
    }

    private synchronized Slot addStock(String rawCode, String label, StockItem item) throws IOException {
        String code = normalizeCode(rawCode);
        validateCode(code);
        if (label == null || label.isBlank()) {
            throw new IllegalArgumentException("Slot label cannot be blank.");
        }
        if ((item.getContent() == null || item.getContent().isBlank())
                && (item.getImageUrl() == null || item.getImageUrl().isBlank())) {
            throw new IllegalArgumentException("Stock content or image URL cannot be blank.");
        }
        if (item.getWeight() < 1) {
            item.setWeight(1);
        }

        Slot slot = machine.getSlots().computeIfAbsent(code, ignored -> new Slot(code, label.trim()));
        slot.setCode(code);
        slot.setLabel(label.trim());
        slot.setEnabled(true);
        slot.getItems().add(item);
        store.save(machine);
        return slot;
    }

    private synchronized void clearSlot(String rawCode) throws IOException {
        Slot slot = requireSlot(rawCode);
        slot.getItems().clear();
        store.save(machine);
    }

    private synchronized void setEnabled(String rawCode, boolean enabled) throws IOException {
        Slot slot = requireSlot(rawCode);
        slot.setEnabled(enabled);
        store.save(machine);
    }

    private synchronized void setOutputChannelId(String channelId) throws IOException {
        machine.setOutputChannelId(cleanSnowflake(channelId));
        store.save(machine);
    }

    private synchronized long coinBalance(String userId) {
        return walletFor(userId).getBalance();
    }

    private synchronized void grantCoins(String userId, long amount) throws IOException {
        if (amount < 1) {
            throw new IllegalArgumentException("Coin grant amount must be at least 1.");
        }
        Wallet wallet = walletFor(userId);
        wallet.setBalance(wallet.getBalance() + amount);
        store.save(machine);
    }

    private synchronized void setCoinManagerRoleId(String roleId) throws IOException {
        machine.setCoinManagerRoleId(cleanSnowflake(roleId));
        store.save(machine);
    }

    private synchronized void setDispenseCost(long cost) throws IOException {
        machine.setDispenseCost(Math.max(0, cost));
        store.save(machine);
    }

    private Wallet walletFor(String userId) {
        return machine.getWallets().computeIfAbsent(userId, ignored -> new Wallet());
    }

    private void recordOwnership(User user, Slot slot, StockItem item, long serial) {
        OwnedItem owned = new OwnedItem();
        owned.setId(itemId(serial));
        owned.setSlotCode(slot.getCode());
        owned.setCategory(slot.getLabel());
        owned.setTitle(itemTitle(item));
        owned.setImageUrl(firstEmbeddableImageUrl(item));
        owned.setAcquiredAt(Instant.now().toString());
        machine.getOwnedItems().computeIfAbsent(user.getId(), ignored -> new ArrayList<>()).add(owned);
    }

    private synchronized String stockSummary() {
        StringBuilder summary = new StringBuilder("```text\n");
        for (Slot slot : sortedSlots(machine)) {
            summary.append(String.format(
                    "%-3s %-14s %3d item(s) %s %d dispensed%n",
                    slot.getCode(),
                    slot.getLabel(),
                    slot.getItems().size(),
                    slot.isEnabled() ? "online " : "offline",
                    slot.getDispensed()
            ));
        }
        summary.append("```");
        return summary.toString();
    }

    private boolean isManager(Member member) {
        if (member == null) {
            return false;
        }
        return member.hasPermission(Permission.MANAGE_SERVER)
                || member.hasPermission(Permission.ADMINISTRATOR)
                || (!ownerId.isBlank() && member.getId().equals(ownerId));
    }

    private boolean isCoinManager(Member member) {
        if (isManager(member)) {
            return true;
        }
        String roleId = machine().getCoinManagerRoleId();
        return member != null
                && roleId != null
                && !roleId.isBlank()
                && member.getRoles().stream().anyMatch(role -> role.getId().equals(roleId));
    }

    private MessageChannel resolveOutputChannel(Guild guild, MessageChannel fallback) {
        String outputChannelId = machine().getOutputChannelId();
        if (guild != null && outputChannelId != null && !outputChannelId.isBlank()) {
            TextChannel output = guild.getTextChannelById(outputChannelId);
            if (output != null) {
                return output;
            }
        }
        return fallback;
    }

    private void dispatchMachineDispense(ButtonInteractionEvent event, MachineView view, DispensedItem dispensed) {
        Message machineMessage = event.getMessage();
        MessageChannel outputChannel = resolveOutputChannel(event.getGuild(), event.getMessageChannel());
        List<String> steps = dispenseStatusSteps(dispensed.slot().getCode());
        MachineView busyView = view.withStatus(steps.getFirst());

        event.editMessageEmbeds(machineEmbeds(machine(), busyView))
                .setComponents(keypadButtons(view.selection(), true))
                .queue(
                        ignored -> {
                            for (int i = 1; i < steps.size(); i++) {
                                MachineView stepView = view.withStatus(steps.get(i));
                                machineMessage.editMessageEmbeds(machineEmbeds(machine(), stepView))
                                        .setComponents(keypadButtons(view.selection(), true))
                                        .queueAfter(i * DISPENSE_STEP_DELAY_MS, TimeUnit.MILLISECONDS, stepIgnored -> {
                                        }, failure -> LOGGER.warn("Could not update vending machine status display.", failure));
                            }

                            long deliveryDelay = Math.max(DISPENSE_STEP_DELAY_MS, steps.size() * DISPENSE_STEP_DELAY_MS);
                            outputChannel.sendMessage(dropBoxMessageContent(dispensed))
                                    .setEmbeds(dispenseEmbed(dispensed))
                                    .queueAfter(
                                            deliveryDelay,
                                            TimeUnit.MILLISECONDS,
                                            delivered -> updateMachineDropBox(machineMessage, delivered),
                                            failure -> showTemporaryMachineStatus(machineMessage, "drop-box jammed")
                                    );
                        },
                        failure -> LOGGER.warn("Could not start vending machine status display.", failure)
                );
    }

    private void dispatchOutOfStock(ButtonInteractionEvent event, MachineView view, String code) {
        Message machineMessage = event.getMessage();
        MessageChannel outputChannel = resolveOutputChannel(event.getGuild(), event.getMessageChannel());
        List<String> steps = List.of("checking " + normalizeSelection(code) + "...", "slot empty");

        event.editMessageEmbeds(machineEmbeds(machine(), view.withStatus(steps.getFirst())))
                .setComponents(keypadButtons(view.selection(), true))
                .queue(
                        ignored -> {
                            MachineView emptyView = view.withStatus(steps.getLast());
                            machineMessage.editMessageEmbeds(machineEmbeds(machine(), emptyView))
                                    .setComponents(keypadButtons(view.selection(), true))
                                    .queueAfter(DISPENSE_STEP_DELAY_MS, TimeUnit.MILLISECONDS, stepIgnored -> {
                                    }, failure -> LOGGER.warn("Could not update vending machine empty status.", failure));

                            outputChannel.sendMessage(outOfStockMessage(event.getUser()))
                                    .queueAfter(
                                            DISPENSE_STEP_DELAY_MS * 2,
                                            TimeUnit.MILLISECONDS,
                                            delivered -> updateMachineDropBox(machineMessage, delivered),
                                            failure -> showTemporaryMachineStatus(machineMessage, "drop-box jammed")
                                    );
                        },
                        failure -> LOGGER.warn("Could not start vending machine empty-slot display.", failure)
                );
    }

    private void showTemporaryMachineStatus(ButtonInteractionEvent event, MachineView view, String status) {
        MachineView statusView = view.withSelection("__").withStatus(status);
        event.editMessageEmbeds(machineEmbeds(machine(), statusView))
                .setComponents(keypadButtons("__"))
                .queue(
                        ignored -> clearMachineStatus(event.getMessage(), 4),
                        failure -> LOGGER.warn("Could not update vending machine error status.", failure)
                );
    }

    private void showTemporaryMachineStatus(Message machineMessage, String status) {
        machineMessage.editMessageEmbeds(machineEmbeds(machine(), MachineView.empty().withStatus(status)))
                .setComponents(keypadButtons("__"))
                .queue(
                        ignored -> clearMachineStatus(machineMessage, 4),
                        failure -> LOGGER.warn("Could not update vending machine temporary status.", failure)
                );
    }

    private void clearMachineStatus(Message machineMessage, long delaySeconds) {
        machineMessage.getChannel().retrieveMessageById(machineMessage.getId())
                .queueAfter(
                        delaySeconds,
                        TimeUnit.SECONDS,
                        current -> {
                            MachineView currentView = machineView(current);
                            if (!currentView.selection().equals("__") || !currentView.latestDropUrl().isBlank()) {
                                return;
                            }
                            current.editMessageEmbeds(machineEmbeds(machine(), MachineView.empty()))
                                    .setComponents(keypadButtons("__"))
                                    .queue(null, failure -> LOGGER.warn("Could not clear vending machine temporary status.", failure));
                        },
                        failure -> LOGGER.warn("Could not retrieve vending machine message before clearing temporary status.", failure)
                );
    }

    private void updateMachineDropBox(Message machineMessage, Message delivered) {
        MachineView view = MachineView.empty().withLatestDrop(delivered.getJumpUrl(), "Grab your item here");
        machineMessage.editMessageEmbeds(machineEmbeds(machine(), view))
                .setComponents(keypadButtons(view.selection()))
                .queue(
                        ignored -> clearMachineDropBoxStatus(machineMessage, delivered.getJumpUrl()),
                        failure -> LOGGER.warn("Could not update vending machine drop-box link.", failure)
                );
    }

    private void clearMachineDropBoxStatus(Message machineMessage, String deliveredJumpUrl) {
        machineMessage.getChannel().retrieveMessageById(machineMessage.getId())
                .queueAfter(
                        LATEST_DROP_STATUS_SECONDS,
                        TimeUnit.SECONDS,
                        current -> {
                            MachineView currentView = machineView(current);
                            if (!currentView.selection().equals("__") || !Objects.equals(currentView.latestDropUrl(), deliveredJumpUrl)) {
                                return;
                            }
                            current.editMessageEmbeds(machineEmbeds(machine(), MachineView.empty()))
                                    .setComponents(keypadButtons("__"))
                                    .queue(null, failure -> LOGGER.warn("Could not clear vending machine drop-box status.", failure));
                        },
                        failure -> LOGGER.warn("Could not retrieve vending machine message before clearing drop-box status.", failure)
                );
    }

    private List<String> dispenseStatusSteps(String code) {
        List<String> configured = machine().getDispenseSequence();
        List<String> steps = new ArrayList<>();
        if (configured != null) {
            for (String configuredStep : configured) {
                String step = statusStep(configuredStep, code);
                if (!step.isBlank()) {
                    steps.add(step);
                }
            }
        }
        return steps.isEmpty() ? List.of("vending...") : steps;
    }

    private static String statusStep(String raw, String code) {
        if (raw == null) {
            return "";
        }
        return raw.replace("{code}", code)
                .replace("`", "")
                .replace('\n', ' ')
                .trim();
    }

    private static String publicErrorStatus(IllegalArgumentException ex) {
        String message = ex.getMessage() == null ? "" : ex.getMessage().toLowerCase(Locale.ROOT);
        if (message.contains("coin") || message.contains("need") || message.contains("balance")) {
            return "purchase denied";
        }
        if (message.contains("empty")) {
            return "slot empty";
        }
        if (message.contains("offline") || message.contains("disabled")) {
            return "slot offline";
        }
        if (message.contains("not stocked")) {
            return "slot not stocked";
        }
        return "selection denied";
    }

    private static boolean isOutOfStockError(IllegalArgumentException ex) {
        String message = ex.getMessage() == null ? "" : ex.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("nothing is inside") || message.contains("rattles sadly");
    }

    private void replyPrivately(InteractionHook hook, String message) {
        hook.editOriginal(message)
                .queue(null, failure -> LOGGER.warn("Could not update private vending machine reply.", failure));
    }

    private String normalizeCode(String raw) {
        return raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT);
    }

    private Slot requireSlot(String rawCode) {
        String code = normalizeCode(rawCode);
        Slot slot = machine.getSlots().get(code);
        if (slot == null) {
            throw new IllegalArgumentException("`" + code + "` is not stocked in this machine.");
        }
        return slot;
    }

    private void validateCode(String code) {
        if (!SLOT_CODE.matcher(code).matches()) {
            throw new IllegalArgumentException("Slot codes must look like `A1`, `B2`, or `C10`.");
        }
    }

    private String cleanSnowflake(String raw) {
        String channelId = raw == null ? "" : raw.replaceAll("[^0-9]", "");
        if (channelId.isBlank()) {
            throw new IllegalArgumentException("Channel ID cannot be blank.");
        }
        return channelId;
    }

    private StockItem choose(Slot slot) {
        int totalWeight = slot.getItems().stream()
                .mapToInt(item -> Math.max(1, item.getWeight()))
                .sum();
        int ticket = random.nextInt(totalWeight);
        int seen = 0;
        for (StockItem item : slot.getItems()) {
            seen += Math.max(1, item.getWeight());
            if (ticket < seen) {
                return item;
            }
        }
        return slot.getItems().getLast();
    }

    private Machine normalizeMachine(Machine loaded) {
        Map<String, Slot> normalized = new LinkedHashMap<>();
        long highestKnownSerial = 0;
        for (Slot slot : loaded.getSlots().values()) {
            String code = normalizeCode(slot.getCode());
            if (code.isBlank()) {
                continue;
            }
            slot.setCode(code);
            highestKnownSerial = Math.max(highestKnownSerial, slot.getDispensed());
            normalized.put(code, slot);
        }
        for (List<OwnedItem> ownedItems : loaded.getOwnedItems().values()) {
            for (OwnedItem ownedItem : ownedItems) {
                highestKnownSerial = Math.max(highestKnownSerial, itemSerial(ownedItem.getId()));
            }
        }
        loaded.setNextItemSerial(Math.max(loaded.getNextItemSerial(), highestKnownSerial + 1));
        loaded.setSlots(normalized);
        removeAlreadyOwnedStock(loaded);
        return loaded;
    }

    private static void removeAlreadyOwnedStock(Machine loaded) {
        Map<String, List<OwnedItem>> ownedByUser = loaded.getOwnedItems();
        if (ownedByUser.isEmpty()) {
            return;
        }

        Map<String, List<OwnedItem>> ownedBySlot = new LinkedHashMap<>();
        for (List<OwnedItem> ownedItems : ownedByUser.values()) {
            for (OwnedItem ownedItem : ownedItems) {
                String slotCode = normalizeStaticCode(ownedItem.getSlotCode());
                if (!slotCode.isBlank()) {
                    ownedBySlot.computeIfAbsent(slotCode, ignored -> new ArrayList<>()).add(ownedItem);
                }
            }
        }

        for (Slot slot : loaded.getSlots().values()) {
            List<OwnedItem> ownedItems = ownedBySlot.get(slot.getCode());
            if (ownedItems == null || ownedItems.isEmpty()) {
                continue;
            }
            slot.getItems().removeIf(item -> alreadyOwned(item, ownedItems));
        }
    }

    private static boolean alreadyOwned(StockItem item, List<OwnedItem> ownedItems) {
        String title = itemTitle(item);
        String imageUrl = firstEmbeddableImageUrl(item);
        for (OwnedItem ownedItem : ownedItems) {
            String ownedImage = ownedItem.getImageUrl() == null ? "" : ownedItem.getImageUrl();
            String ownedTitle = ownedItem.getTitle() == null ? "" : ownedItem.getTitle();
            if (!imageUrl.isBlank() && imageUrl.equals(ownedImage)) {
                return true;
            }
            if (!title.isBlank() && title.equals(ownedTitle)) {
                return true;
            }
        }
        return false;
    }

    private static String normalizeStaticCode(String raw) {
        return raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT);
    }

    private static void registerCommands(JDA jda, String guildId) {
        List<CommandData> commands = commands();
        if (guildId != null && !guildId.isBlank()) {
            Guild guild = jda.getGuildById(guildId);
            if (guild == null) {
                LOGGER.warn("GUILD_ID {} was configured, but the bot cannot see that guild. Registering global commands instead.", guildId);
                jda.updateCommands().addCommands(commands).queue();
                return;
            }
            guild.updateCommands().addCommands(commands).queue();
            LOGGER.info("Registered slash commands for guild {}.", guildId);
            return;
        }

        jda.updateCommands().addCommands(commands).queue();
        LOGGER.info("Registered global slash commands.");
    }

    private static List<CommandData> commands() {
        return List.of(
                Commands.slash("machine", "Post the current vending machine display."),
                Commands.slash("vend", "Dispense an item from a slot.")
                        .addOptions(new OptionData(OptionType.STRING, "code", "Slot code, like A1.", true)),
                Commands.slash("stock", "Manage vending machine stock.")
                        .addSubcommands(
                                new SubcommandData("list", "List slots and stock counts."),
                                new SubcommandData("reload", "Reload stock/settings from disk."),
                                new SubcommandData("add", "Add an item to a slot.")
                                        .addOptions(
                                                new OptionData(OptionType.STRING, "code", "Slot code, like A1.", true),
                                                new OptionData(OptionType.STRING, "label", "Slot label, like Cats.", true),
                                                new OptionData(OptionType.STRING, "content", "Text or URL to dispense.", true),
                                                new OptionData(OptionType.STRING, "image-url", "Optional image URL for the embed.", false),
                                                new OptionData(OptionType.STRING, "title", "Optional collectible title.", false),
                                                new OptionData(OptionType.BOOLEAN, "rare", "Mark this item as rare.", false)
                                        ),
                                new SubcommandData("add-image", "Add an image-only collectible to a slot.")
                                        .addOptions(
                                                new OptionData(OptionType.STRING, "code", "Slot code, like A1.", true),
                                                new OptionData(OptionType.STRING, "label", "Slot label, like Cats.", true),
                                                new OptionData(OptionType.STRING, "image-url", "Direct image URL or simple Imgur URL.", true),
                                                new OptionData(OptionType.STRING, "title", "Optional collectible title.", false),
                                                new OptionData(OptionType.BOOLEAN, "rare", "Mark this item as rare.", false)
                                        ),
                                new SubcommandData("clear", "Remove every item from a slot.")
                                        .addOptions(new OptionData(OptionType.STRING, "code", "Slot code, like A1.", true)),
                                new SubcommandData("enable", "Enable a slot.")
                                        .addOptions(new OptionData(OptionType.STRING, "code", "Slot code, like A1.", true)),
                                new SubcommandData("disable", "Disable a slot.")
                                        .addOptions(new OptionData(OptionType.STRING, "code", "Slot code, like A1.", true)),
                                new SubcommandData("set-output", "Set the dispense output channel by ID.")
                                        .addOptions(new OptionData(OptionType.STRING, "channel-id", "Discord text channel ID.", true))
                        ),
                Commands.slash("coins", "View and manage vending machine coins.")
                        .addSubcommands(
                                new SubcommandData("balance", "Show a user's coin balance.")
                                        .addOptions(new OptionData(OptionType.USER, "user", "User to check. Defaults to you.", false)),
                                new SubcommandData("grant", "Grant coins to a user.")
                                        .addOptions(
                                                new OptionData(OptionType.USER, "user", "User to receive coins.", true),
                                                new OptionData(OptionType.INTEGER, "amount", "Number of coins to grant.", true)
                                        ),
                                new SubcommandData("set-manager-role", "Set the role allowed to grant coins.")
                                        .addOptions(new OptionData(OptionType.STRING, "role-id", "Discord role ID or mention.", true)),
                                new SubcommandData("set-cost", "Set how many coins one dispense costs.")
                                        .addOptions(new OptionData(OptionType.INTEGER, "amount", "Coin cost per dispense.", true))
                        )
        );
    }

    private static List<MessageEmbed> machineEmbeds(Machine machine, MachineView view) {
        Slot selectedSlot = selectedSlot(machine, view.selection());
        String selection = displaySelection(view.selection());
        String status = view.statusOverride().isBlank() ? machineStatus(view.selection(), selectedSlot) : view.statusOverride();

        EmbedBuilder displayEmbed = new EmbedBuilder()
                .setDescription(
                        statusLine(view, status) + "\n"
                                + "`INPUT   " + selection + "`"
                )
                .setColor(MACHINE_YELLOW);

        if (view.latestDropUrl() != null && !view.latestDropUrl().isBlank()) {
            displayEmbed.setUrl(view.latestDropUrl());
        }

        if (!machineArtAvailable()) {
            displayEmbed.setTitle(machine.getTitle());
            return List.of(displayEmbed.build());
        }

        MessageEmbed art = new EmbedBuilder()
                .setTitle(machine.getTitle())
                .setImage(MACHINE_ART_URL)
                .setColor(MACHINE_YELLOW)
                .build();
        return List.of(art, displayEmbed.build());
    }

    private static boolean machineArtAvailable() {
        return VendingMachineBot.class.getResource(MACHINE_ART_RESOURCE) != null;
    }

    private static FileUpload machineArtUpload() {
        InputStream stream = VendingMachineBot.class.getResourceAsStream(MACHINE_ART_RESOURCE);
        if (stream == null) {
            LOGGER.warn("Machine art resource {} was not found.", MACHINE_ART_RESOURCE);
            return null;
        }
        return FileUpload.fromData(stream, MACHINE_ART_FILE);
    }

    private static String statusLine(MachineView view, String status) {
        if (view.selection().equals("__") && view.latestDropUrl() != null && !view.latestDropUrl().isBlank()) {
            return "`STATUS ` [" + markdownEscape(view.latestDropLabel()) + "](" + view.latestDropUrl() + ")";
        }
        return "`STATUS  " + displayLine(status, 42) + "`";
    }

    private static String dropBoxMessageContent(DispensedItem dispensed) {
        return "Claimed by <@" + dispensed.ownerId() + ">";
    }

    private static String outOfStockMessage(User user) {
        return user.getAsMention() + " Oh no! You chose an option that's out of stock! Anyway-";
    }

    private static String markdownEscape(String value) {
        if (value == null || value.isBlank()) {
            return "latest drop below";
        }
        return value.replace("[", "\\[").replace("]", "\\]");
    }

    private static MessageEmbed dispenseEmbed(DispensedItem dispensed) {
        Slot slot = dispensed.slot();
        StockItem item = dispensed.item();
        String content = item.getContent() == null ? "" : item.getContent().trim();
        String contentImageUrl = embeddableImageUrl(content);
        String imageUrl = firstEmbeddableImageUrl(item);
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle(slot.getLabel() + ": " + itemId(dispensed.serial()) + " - " + itemTitle(item))
                .setColor(item.isRare() ? MACHINE_YELLOW : DROPBOX_GREEN)
                .setFooter("Claimed by @" + dispensed.ownerName())
                .setTimestamp(Instant.now());

        if (!content.isBlank() && contentImageUrl.isBlank()) {
            embed.setDescription(content);
        }

        if (!imageUrl.isBlank()) {
            embed.setImage(imageUrl);
        }
        return embed.build();
    }

    private static List<ActionRow> keypadButtons(String selection) {
        return keypadButtons(selection, false);
    }

    private static List<ActionRow> keypadButtons(String selection, boolean disabled) {
        String normalized = normalizeSelection(selection);
        boolean ready = completeSelection(normalized);
        return List.of(
                ActionRow.of(
                        rowButton("A", normalized).withDisabled(disabled),
                        rowButton("B", normalized).withDisabled(disabled),
                        rowButton("C", normalized).withDisabled(disabled)
                ),
                ActionRow.of(
                        columnButton("1", normalized).withDisabled(disabled),
                        columnButton("2", normalized).withDisabled(disabled),
                        columnButton("3", normalized).withDisabled(disabled)
                ),
                ActionRow.of(
                        Button.success(DISPENSE_ID, ready ? "Dispense " + normalized : "Dispense").withDisabled(disabled || !ready),
                        Button.secondary(CLEAR_ID, "Clear").withDisabled(disabled || normalized.equals("__"))
                )
        );
    }

    private static List<Slot> enabledSlots(Machine machine) {
        return machine.getSlots().values().stream()
                .filter(Slot::isEnabled)
                .sorted(Comparator.comparing(Slot::getCode))
                .toList();
    }

    private static List<Slot> sortedSlots(Machine machine) {
        return machine.getSlots().values().stream()
                .sorted(Comparator.comparing(Slot::getCode))
                .toList();
    }

    private static Button rowButton(String row, String selection) {
        boolean selected = normalizeSelection(selection).charAt(0) == row.charAt(0);
        Button button = Button.secondary(KEY_PREFIX + row, row);
        return selected ? button.withStyle(ButtonStyle.SUCCESS) : button;
    }

    private static Button columnButton(String column, String selection) {
        boolean selected = normalizeSelection(selection).charAt(1) == column.charAt(0);
        Button button = Button.secondary(KEY_PREFIX + column, column);
        return selected ? button.withStyle(ButtonStyle.SUCCESS) : button;
    }

    private static String dropBoxLabel(String latestDropUrl, String latestDropLabel) {
        String label = latestDropLabel == null || latestDropLabel.isBlank() ? "latest drop below" : latestDropLabel;
        if (latestDropUrl == null || latestDropUrl.isBlank()) {
            return label;
        }
        return "[" + label + "](" + latestDropUrl + ")";
    }

    private static String itemId(long serial) {
        return String.format(Locale.ROOT, "ID %04d", Math.max(0, serial));
    }

    private static long itemSerial(String itemId) {
        if (itemId == null || itemId.isBlank()) {
            return 0;
        }
        String digits = itemId.replaceAll("\\D+", "");
        if (digits.isBlank()) {
            return 0;
        }
        try {
            return Long.parseLong(digits);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private static String itemTitle(StockItem item) {
        String title = item.getTitle();
        if (title != null && !title.isBlank()) {
            return displayLine(title, 80);
        }

        String content = item.getContent();
        if (content != null && !content.isBlank() && embeddableImageUrl(content).isBlank()) {
            return displayLine(content, 80);
        }

        return "Untitled";
    }

    private static String firstEmbeddableImageUrl(StockItem item) {
        String imageUrl = embeddableImageUrl(item.getImageUrl());
        if (!imageUrl.isBlank()) {
            return imageUrl;
        }
        return embeddableImageUrl(item.getContent());
    }

    private static String embeddableImageUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.isBlank()) {
            return "";
        }

        String url = rawUrl.trim();
        if (url.startsWith("<") && url.endsWith(">") && url.length() > 2) {
            url = url.substring(1, url.length() - 1).trim();
        }

        String normalized = normalizeImgurUrl(url);
        if (!normalized.isBlank()) {
            return normalized;
        }

        if (looksLikeDirectImageUrl(url)) {
            return url;
        }
        return "";
    }

    private static String normalizeImgurUrl(String url) {
        String clean = url.split("[?#]", 2)[0];
        String lower = clean.toLowerCase(Locale.ROOT);
        if (!(lower.startsWith("http://") || lower.startsWith("https://"))) {
            return "";
        }

        if (lower.startsWith("http://")) {
            clean = "https://" + clean.substring("http://".length());
            lower = clean.toLowerCase(Locale.ROOT);
        }

        String path;
        if (lower.startsWith("https://i.imgur.com/")) {
            path = clean.substring("https://i.imgur.com/".length());
            if (path.isBlank() || path.contains("/")) {
                return "";
            }
            if (path.toLowerCase(Locale.ROOT).endsWith(".gifv")) {
                return clean.substring(0, clean.length() - ".gifv".length()) + ".gif";
            }
            return hasImageExtension(path) ? clean : clean + ".jpg";
        }

        if (lower.startsWith("https://imgur.com/")) {
            path = clean.substring("https://imgur.com/".length());
        } else if (lower.startsWith("https://www.imgur.com/")) {
            path = clean.substring("https://www.imgur.com/".length());
        } else {
            return "";
        }

        if (path.isBlank() || path.contains("/")) {
            return "";
        }
        return "https://i.imgur.com/" + (hasImageExtension(path) ? path : path + ".jpg");
    }

    private static boolean looksLikeDirectImageUrl(String url) {
        String lower = url.toLowerCase(Locale.ROOT);
        if (!(lower.startsWith("http://") || lower.startsWith("https://"))) {
            return false;
        }
        return hasImageExtension(lower.split("[?#]", 2)[0]);
    }

    private static boolean hasImageExtension(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        return lower.endsWith(".jpg")
                || lower.endsWith(".jpeg")
                || lower.endsWith(".png")
                || lower.endsWith(".gif")
                || lower.endsWith(".webp");
    }

    private static MachineView machineView(Message message) {
        if (message.getEmbeds().isEmpty()) {
            return MachineView.empty();
        }

        StringBuilder descriptionBuilder = new StringBuilder();
        for (MessageEmbed embed : message.getEmbeds()) {
            String part = embed.getDescription();
            if (part != null && !part.isBlank()) {
                descriptionBuilder.append(part).append('\n');
            }
        }

        String description = descriptionBuilder.toString();
        if (description == null || description.isBlank()) {
            return MachineView.empty();
        }

        String selection = selectionFrom(description);

        String latestDropUrl = "";
        String latestDropLabel = "latest drop below";
        java.util.regex.Matcher statusLinkMatcher = STATUS_LINK_PATTERN.matcher(description);
        if (statusLinkMatcher.find()) {
            latestDropLabel = statusLinkMatcher.group(1);
            latestDropUrl = statusLinkMatcher.group(2);
        } else {
            java.util.regex.Matcher legacyLatestLinkMatcher = LEGACY_LATEST_LINK_PATTERN.matcher(description);
            if (legacyLatestLinkMatcher.find()) {
                latestDropLabel = legacyLatestLinkMatcher.group(1);
                latestDropUrl = legacyLatestLinkMatcher.group(2);
            } else {
                java.util.regex.Matcher legacyLatestTextMatcher = LEGACY_LATEST_TEXT_PATTERN.matcher(description);
                if (legacyLatestTextMatcher.find()) {
                    latestDropLabel = legacyLatestTextMatcher.group(1).trim();
                } else {
                    java.util.regex.Matcher dropLinkMatcher = DROPBOX_LINK_PATTERN.matcher(description);
                    if (dropLinkMatcher.find()) {
                        latestDropLabel = dropLinkMatcher.group(1);
                        latestDropUrl = dropLinkMatcher.group(2);
                    } else {
                        java.util.regex.Matcher dropTextMatcher = DROPBOX_TEXT_PATTERN.matcher(description);
                        if (dropTextMatcher.find()) {
                            latestDropLabel = dropTextMatcher.group(1).trim();
                        }
                    }
                }
            }
        }

        return new MachineView(selection, latestDropUrl, latestDropLabel, "");
    }

    private static String applyKey(String selection, String key) {
        String normalized = normalizeSelection(selection);
        char row = normalized.charAt(0);
        char column = normalized.charAt(1);
        String upperKey = key == null ? "" : key.toUpperCase(Locale.ROOT);

        if (upperKey.matches("[A-C]")) {
            row = upperKey.charAt(0);
        } else if (upperKey.matches("[1-3]")) {
            column = upperKey.charAt(0);
        }
        return "" + row + column;
    }

    private static String normalizeSelection(String selection) {
        String safe = selection == null ? "__" : selection.toUpperCase(Locale.ROOT).replace('-', '_');
        char row = safe.length() > 0 && safe.charAt(0) >= 'A' && safe.charAt(0) <= 'C' ? safe.charAt(0) : '_';
        char column = safe.length() > 1 && safe.charAt(1) >= '1' && safe.charAt(1) <= '3' ? safe.charAt(1) : '_';
        return "" + row + column;
    }

    private static boolean completeSelection(String selection) {
        return normalizeSelection(selection).matches("[A-C][1-3]");
    }

    private static String displaySelection(String selection) {
        return normalizeSelection(selection);
    }

    private static Slot selectedSlot(Machine machine, String selection) {
        if (!completeSelection(selection)) {
            return null;
        }
        return machine.getSlots().get(normalizeSelection(selection));
    }

    private static String selectionFrom(String description) {
        java.util.regex.Matcher inputMatcher = INPUT_PATTERN.matcher(description);
        if (inputMatcher.find()) {
            return normalizeSelection(inputMatcher.group(1));
        }

        java.util.regex.Matcher selectionMatcher = SELECTION_PATTERN.matcher(description);
        if (selectionMatcher.find()) {
            return normalizeSelection(selectionMatcher.group(1));
        }
        return "__";
    }

    private static String machineStatus(String selection, Slot selectedSlot) {
        String normalized = normalizeSelection(selection);
        if (normalized.equals("__")) {
            return "choose row and number";
        }
        if (normalized.charAt(0) == '_') {
            return "choose row A-C";
        }
        if (normalized.charAt(1) == '_') {
            return "choose number 1-3";
        }
        if (selectedSlot == null) {
            return "slot not stocked";
        }
        if (!selectedSlot.isEnabled()) {
            return "slot offline";
        }
        if (selectedSlot.getItems().isEmpty()) {
            return "slot empty";
        }
        return "ready to dispense";
    }

    private static String displayLine(String value, int maxLength) {
        String line = value == null || value.isBlank() ? "-" : value.replace('\n', ' ').replace('`', '\'').trim();
        if (line.length() <= maxLength) {
            return line;
        }
        return line.substring(0, Math.max(0, maxLength - 3)) + "...";
    }

    private record MachineView(String selection, String latestDropUrl, String latestDropLabel, String statusOverride) {
        static MachineView empty() {
            return new MachineView("__", "", "latest drop below", "");
        }

        MachineView withSelection(String selection) {
            return new MachineView(normalizeSelection(selection), "", "latest drop below", "");
        }

        MachineView withLatestDrop(String latestDropUrl, String latestDropLabel) {
            return new MachineView(selection, latestDropUrl == null ? "" : latestDropUrl, latestDropLabel, "");
        }

        MachineView withStatus(String status) {
            return new MachineView(selection, latestDropUrl, latestDropLabel, status == null ? "" : status);
        }
    }

    public record BotConfig(String token, String guildId, String ownerId, Path dataPath) {
        public static BotConfig load() {
            Dotenv dotenv = Dotenv.configure().ignoreIfMissing().load();
            String token = read(dotenv, "DISCORD_TOKEN", read(dotenv, "TOKEN", ""));
            if (token == null || token.isBlank()) {
                throw new IllegalStateException("Missing DISCORD_TOKEN. Copy .env.example to .env and add your bot token.");
            }

            return new BotConfig(
                    token.trim(),
                    read(dotenv, "GUILD_ID", "").trim(),
                    read(dotenv, "OWNER_ID", "").trim(),
                    Path.of(read(dotenv, "DATA_PATH", "data/machine.json"))
            );
        }

        private static String read(Dotenv dotenv, String key, String fallback) {
            String value = System.getenv(key);
            if (value != null && !value.isBlank()) {
                return value;
            }
            value = dotenv.get(key);
            return value == null ? fallback : value;
        }
    }

    public record DispensedItem(Slot slot, StockItem item, long serial, String ownerId, String ownerName) {
    }

    public static final class MachineStore {
        private final ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        private final Path path;

        public MachineStore(Path path) {
            this.path = path;
        }

        public synchronized Machine loadOrCreateDefault() throws IOException {
            if (Files.notExists(path)) {
                Machine defaultMachine = Machine.defaultMachine();
                save(defaultMachine);
                return defaultMachine;
            }
            return mapper.readValue(path.toFile(), Machine.class);
        }

        public synchronized void save(Machine value) throws IOException {
            Path parent = path.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            mapper.writeValue(path.toFile(), value);
        }
    }

    public static final class Machine {
        private String title = "VENDING MACHINE";
        private String inputChannelId = "";
        private String outputChannelId = "";
        private long dispenseCost = 1;
        private long nextItemSerial = 1;
        private String coinManagerRoleId = "";
        private List<String> dispenseSequence = new ArrayList<>(List.of(
                "`coin inserted for {code}...`",
                "`gears turning...`",
                "`clunk.`"
        ));
        private Map<String, Slot> slots = new LinkedHashMap<>();
        private Map<String, Wallet> wallets = new LinkedHashMap<>();
        private Map<String, List<OwnedItem>> ownedItems = new LinkedHashMap<>();

        public static Machine defaultMachine() {
            Machine machine = new Machine();
            machine.putDefaultSlot("A1", "Cats", "A tiny cat fact escaped the vending coil.");
            machine.putDefaultSlot("A2", "Dogs", "A good dog appears with absolutely no context.");
            machine.putDefaultSlot("A3", "Otters", "An otter has been dispensed. It looks busy.");
            machine.putDefaultSlot("B1", "Memes", "Fresh meme packet. Contents may settle during shipping.");
            machine.putDefaultSlot("B2", "Wholesome", "You are doing better than the machine expected.");
            machine.putDefaultSlot("B3", "Cringe", "This slot makes a worrying noise, then hands you cringe.");
            machine.putDefaultSlot("C1", "Quotes", "\"The machine believes in your bit.\"");
            machine.putDefaultSlot("C2", "Waifu", "A mysterious character card slides into the dropbox.");
            machine.putDefaultSlot("C3", "Frank", "Frank was here. Frank may still be here.");
            return machine;
        }

        private void putDefaultSlot(String code, String label, String content) {
            Slot slot = new Slot(code, label);
            slot.getItems().add(new StockItem(content, "", false, 1));
            slots.put(code, slot);
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getInputChannelId() {
            return inputChannelId;
        }

        public void setInputChannelId(String inputChannelId) {
            this.inputChannelId = inputChannelId;
        }

        public String getOutputChannelId() {
            return outputChannelId;
        }

        public void setOutputChannelId(String outputChannelId) {
            this.outputChannelId = outputChannelId;
        }

        public long getDispenseCost() {
            return dispenseCost;
        }

        public void setDispenseCost(long dispenseCost) {
            this.dispenseCost = Math.max(0, dispenseCost);
        }

        public long getNextItemSerial() {
            return Math.max(1, nextItemSerial);
        }

        public void setNextItemSerial(long nextItemSerial) {
            this.nextItemSerial = Math.max(1, nextItemSerial);
        }

        public String getCoinManagerRoleId() {
            return coinManagerRoleId;
        }

        public void setCoinManagerRoleId(String coinManagerRoleId) {
            this.coinManagerRoleId = coinManagerRoleId;
        }

        public List<String> getDispenseSequence() {
            if (dispenseSequence == null || dispenseSequence.isEmpty()) {
                dispenseSequence = new ArrayList<>(List.of("`coin inserted for {code}...`", "`clunk.`"));
            }
            return dispenseSequence;
        }

        public void setDispenseSequence(List<String> dispenseSequence) {
            this.dispenseSequence = dispenseSequence;
        }

        public Map<String, Slot> getSlots() {
            if (slots == null) {
                slots = new LinkedHashMap<>();
            }
            return slots;
        }

        public void setSlots(Map<String, Slot> slots) {
            this.slots = slots;
        }

        public Map<String, Wallet> getWallets() {
            if (wallets == null) {
                wallets = new LinkedHashMap<>();
            }
            return wallets;
        }

        public void setWallets(Map<String, Wallet> wallets) {
            this.wallets = wallets;
        }

        public Map<String, List<OwnedItem>> getOwnedItems() {
            if (ownedItems == null) {
                ownedItems = new LinkedHashMap<>();
            }
            return ownedItems;
        }

        public void setOwnedItems(Map<String, List<OwnedItem>> ownedItems) {
            this.ownedItems = ownedItems;
        }
    }

    public static final class Slot {
        private String code = "";
        private String label = "";
        private boolean enabled = true;
        private long dispensed = 0;
        private List<StockItem> items = new ArrayList<>();

        public Slot() {
        }

        public Slot(String code, String label) {
            this.code = code;
            this.label = label;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public long getDispensed() {
            return dispensed;
        }

        public void setDispensed(long dispensed) {
            this.dispensed = dispensed;
        }

        public List<StockItem> getItems() {
            if (items == null) {
                items = new ArrayList<>();
            }
            return items;
        }

        public void setItems(List<StockItem> items) {
            this.items = items;
        }
    }

    public static final class Wallet {
        private long balance = 0;

        public long getBalance() {
            return balance;
        }

        public void setBalance(long balance) {
            this.balance = Math.max(0, balance);
        }
    }

    public static final class OwnedItem {
        private String id = "";
        private String slotCode = "";
        private String category = "";
        private String title = "";
        private String imageUrl = "";
        private String acquiredAt = "";

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getSlotCode() {
            return slotCode;
        }

        public void setSlotCode(String slotCode) {
            this.slotCode = slotCode;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public String getAcquiredAt() {
            return acquiredAt;
        }

        public void setAcquiredAt(String acquiredAt) {
            this.acquiredAt = acquiredAt;
        }
    }

    public static final class StockItem {
        private String content = "";
        private String imageUrl = "";
        private String title = "";
        private boolean rare = false;
        private int weight = 1;

        public StockItem() {
        }

        public StockItem(String content, String imageUrl, boolean rare, int weight) {
            this(content, imageUrl, "", rare, weight);
        }

        public StockItem(String content, String imageUrl, String title, boolean rare, int weight) {
            this.content = content;
            this.imageUrl = imageUrl;
            this.title = title;
            this.rare = rare;
            this.weight = weight;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public boolean isRare() {
            return rare;
        }

        public void setRare(boolean rare) {
            this.rare = rare;
        }

        public int getWeight() {
            return weight;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }
    }
}
